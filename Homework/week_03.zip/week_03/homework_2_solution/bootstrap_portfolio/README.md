# Bootstrap Portfolio

Credit goes to RCP Student [Nathaniel Quashie](http://github.com/bklynate) for his exemplary Bootstrap Portfolio. This reference solution is essentially [his submission for the Unit 2 homework assignment](https://github.com/bklynate/bootstrap-bp).
